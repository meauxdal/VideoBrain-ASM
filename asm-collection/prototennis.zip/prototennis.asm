; Transcribed / OCR by e5frog May 2012
; v 1.0
; All machine code checked, all mnemonics checked
;
; dasm file.asm -f3 -ofile.bin  to compile

         processor f8

         org $1000

         db   $aa,$55                                                          ;cart signature
         db   $01                                                              ;background color
         db   $00,$25,$09,$13,$07,$13,$00,$07,$0b,$2b,$2b,$01,$21,$00,$00      ;name - _PROTO__TENNIS_

START:   JMP $1800


         org $1200

         incbin "US4232374 data $1200.bin"

;        ****************************
;        *PROGRAM                   *
;        ****************************
;        *
;        *
;        *
;        *******************************************
;        *                                         *
;        *     DECLARATIONS                        *
;        *                                         *
;        *******************************************
;        *
;        *
HU    EQU $A
HL    EQU $B
;S    EQU $C
;        *
;        *UM1 REGISTERS*
;        ***************
;PAGE 21 22
COM   EQU $8F7
ZOOM  EQU $8F6
BGPN  EQU $8F5
;        *
;        *
;        *******************************************
;        *                                         *
;        *     MAIN PROGRAM                        *
;        *                                         *
;        *******************************************
;        *
;        *INITIALIZE*
;        ************

         org $1800
;        *
;        *CLEAR I/O SYSTEM
                CLR            ; 1800 70
                OUTS 6         ; 1801 b6
                OUTS 14        ; 1802 be
                OUTS 1         ; 1803 b1       DISABLE JOYSTICKS
                DI             ; 1804 1a       DISABLE CPU INTERRUPTS
;        *
;        *INITIALIZE SCRATCH PAD VARIABLES
                LISU 2         ; 1805 62
                LISL 1         ; 1806 69
                LIS 4          ; 1807 74 -- guess
                LR   I,A       ; 1808 5d
;        *
                LI   $b4       ; 1809 20 b4
                LR   $1,A      ; 180b 51
                LI   $90       ; 180c 20 90
                LR   I,A       ; 180e 5d
                LR   I,A       ; 180f 5d
;        *
                CLR            ; 1810 70
                LR   S,A       ; 1811 5c
                LISL 6         ; 1812 6e
                LI   $3c       ; 1813 20 3c
                LR   S,A       ; 1815 5c
;        *
                LISU 5         ; 1816 65
                LISL 0         ; 1817 68
                CLR            ; 1818 70
                LR   I,A       ; 1819 5d
                LR   I,A       ; 181a 5d
                LR   I,A       ; 181b 5d
                LI   $56       ; 181c 20 56
                LR   I,A       ; 181e 5d
                CLR            ; 181f 70
                LR   I,A       ; 1820 5d
                COM            ; 1821 18
                LR   I,A       ; 1822 5d
                LISU 6         ; 1823 66
                LISL 0         ; 1824 68
                CLR            ; 1825 70
                LR   S,A       ; 1826 5c
;        *
                LI   $18       ; 1827 20 18
                LR   IS,A       ; 1829 0b
; PAGE 55 56
                LIS  12        ; 182a 7c
                LR   I,A       ; 182b 5d
                LIS  4         ; 182c 74
                LR   I,A       ; 182d 5d
                LIS  11        ; 182e 7b
                LR   I,A       ; 182f 5d
                LIS  7         ; 1830 77
                LR   I,A       ; 1831 5d
                LIS  8         ; 1832 78
                LR   I,A       ; 1833 5d
                LIS  9         ; 1834 79
                LR   I,A       ; 1835 5d
                LIS  2         ; 1836 72
                LR   I,A       ; 1837 5d
                LIS  3         ; 1838 73
                LR   I,A       ; 1839 5d
                LISU 4         ; 183a 64
                LIS  5         ; 183b 75
                LR   I,A       ; 183c 5d
                LIS  10        ; 183d 7a
                LR   I,A       ; 183e 5d
                LIS  6         ; 183f 76
                LR   I,A       ; 1840 5d
                LIS  0         ; 1841 70
                LR   I,A       ; 1842 5d
                LIS  1         ; 1843 71
                LR   I,A       ; 1844 5d
;        *
;        *ZERO UM-1 WRITE ONLY REGISTERS
                DCI  $08f0     ; 1845 2a 08 f0
                LIS  7         ; 1848 77
                LR   $a,A      ; 1849 5a
                PI   A1dda     ; 184a 28 1d da
;        *
;        *CLEAR UM-1 READ/WRITE REGISTERS
                DCI  $0800     ; 184d 2a 08 00
                LI   $90       ; 1850 20 90
                LR   $a,A      ; 1852 5a
                PI   A1dca     ; 1853 28 1d ca
;        *
;        *MOVE INITIAL UPDATE DATA INTO RAM
                DCI  $0c1c     ; 1856 2a 0c 1c
                XDC            ; 1859 2c
                DCI  $125a     ; 185a 2a 12 5a
                LI   $83       ; 185d 20 83
                LR   $a,A      ; 185f 5a
                PI   A1dd1     ; 1860 28 1d d1
;        *
;        *LOAD UM-1 READ/WRITE REGISTERS & DISPLAY
;        *
                DCI  $125a     ; 1863 2a 12 5a INITIALIZE UM-1 REGISTERS
                PI   A1e50     ; 1866 28 1e 50
                CLR            ; 1869 70
                LR   $a,A      ; 186a 5a       SYNC ON LINE 0
                PI   A1de0     ; 186b 28 1d e0
                LI   $44       ; 186e 20 44
                DCI  $08f7     ; 1870 2a 08 f7 SELECT LIST A AND
                ST             ; 1873 17 -- guess
                LISU 2         ; 1874 62
                LISL 0         ; 1875 68
                LR   I,A       ; 1876 5d       SET PROGRAM COPY OF COM
;
;
;
A1877:          LISU 2         ; 1877 62
                LISL 1         ; 1878 69
                CLR            ; 1879 70
; PAGE 57 58
                XS   S         ; 187a ec
                BM   A18f5     ; 187b 91 79    IF MODE = SERVE [
;        *
                LR   A,$1      ; 187d 41
                CI   $08       ; 187e 25 08
                BZ   A1886     ; 1880 84 05    IF X=CLB+BW2
                CI   $b4       ; 1882 25 b4
                BNZ  A18f7     ; 1884 94 72    OR X=CRB+BW2 [
A1886:          LISL 6         ; 1886 6e
                LISU 2         ; 1887 62
                DS   S         ; 1888 3c       BBK1 <= BBK1-1
                BZ   A18b7     ; 1889 84 2d    IF BBK1.NE.0 [
;        *
;        *BUILD SCORE OBJECTS
                LISU 5         ; 188b 65
                LISL 0         ; 188c 68
                LR   A,S       ; 188d 4c
                SR   4         ; 188e 14
                LR   $a,A      ; 188f 5a
                DCI  $0c00     ; 1890 2a 0c 00
                PI   A1e96     ; 1893 28 1e 96 CALL MOVD(LSCD/16,LSCR)
                LR   A,S       ; 1896 4c
                SL   4         ; 1897 15
                SR   4         ; 1898 14
                LR   $a,A      ; 1899 5a
                DCI  $0c01     ; 189a 2a 0c 01
                PI   A1e96     ; 189d 28 1e 96 CALL MOVD(LSCD.MOD.16,LSCR+1
                LISL 1         ; 18a0 69
                LR   A,S       ; 18a1 4c
                SR   4         ; 18a2 14
                LR   $a,A      ; 18a3 5a
                DCI  $0c0e     ; 18a4 2a 0c 0e
                PI   A1e96     ; 18a7 28 1e 96 CALL MOVD(RSCD/16,RSCR)
                LR   A,S       ; 18aa 4c
                SL   4         ; 18ab 15
                SR   4         ; 18ac 14
                LR   $a,A      ; 18ad 5a -- guess
                DCI  $0c0f     ; 18ae 2a 0c 0f
                PI   A1e96     ; 18b1 28 1e 96 CALL MOVD(RSCR.MOD.16,RSCR+1
                JMP  A1996     ; 18b4 29 19 96          GOTO MP0]
A18b7:          LIS  1         ; 18b7 71
                LR   S,A       ; 18b8 5c             BBK1 <= 1
                LISL 1         ; 18b9 69
                LR   A,S       ; 18ba 4c
                SL   1         ; 18bb 13
                LI   $55       ; 18bc 20 55
                BP   A18c2     ; 18be 81 03
                LI   $67       ; 18c0 20 67
A18c2:          LISU 5         ; 18c2 65
                LISL 3         ; 18c3 6b
                LR   S,A       ; 18c4 5c
                LI   $ca       ; 18c5 20 ca
                LISL 5         ; 18c7 6d
                LR   S,A       ; 18c8 5c             BBY <= CBB-BBH
                LI   $f9       ; 18c9 20 f9
                LISU 2         ; 18cb 62
                LISL 1         ; 18cc 69
                NS   S         ; 18cd fc
                LR   I,A       ; 18ce 5d              PSTA <= PSTA-BBYH-BB??
                LISL 2         ; 18cf 6a -- guess
                LIS  1         ; 18d0 71             BVX <= BBVX
                LISU 5         ; 18d1 65
                BM   A18d6     ; 18d2 91 03          IF NXTS=L [
                LI   $ff       ; 18d4 20 ff             BVX<=-BBVX
A18d6:          LR   S,A       ; 18d6 5c                ]
                LI   $fe       ; 18d7 20 fe
                LISL 4         ; 18d9 6c
                LR   D,A       ; 18da 5e             BVY <= -BBVY
                LR   A,S       ; 18db 4c
                BM   A18e2     ; 18dc 91 05          IF NXTS=L [
; PAGE 59 60
                AI   $f6       ; 18de 24 f6
                BR   A18e4     ; 18e0 90 03
A18e2:          AI   $0a       ; 18e2 24 0a
A18e4:          LR   $1,A      ; 18e4 51
                LI   $d2       ; 18e5 20 d2
                LR   $3,A      ; 18e7 53
                CLR            ; 18e8 70
                LR   $4,A      ; 18e9 54
                LR   $6,A      ; 18ea 56
                LISL 2         ; 18eb 6a
                LR   A,S       ; 18ec 4c
                LR   $5,A      ; 18ed 55
                LI   $fe       ; 18ee 20 fe
                LR   $7,A      ; 18f0 57
                LISU 2         ; 18f1 62
                LISL 7         ; 18f2 6f
                LIS  7         ; 18f3 77
                LR   S,A       ; 18f4 5c
A18f5:          BR   A191e     ; 18f5 90 28
A18f7:          CLR            ; 18f7 70
                LISU 5         ; 18f8 65
                LISL 2         ; 18f9 6a
                XS   S         ; 18fa ec
                BP   A1903     ; 18fb 81 07
                LISL 3         ; 18fd 6b
                AS   D         ; 18fe ce
                CI   $35       ; 18ff 25 35
                BNC  A191e     ; 1901 92 1c
;
A1903:          CLR            ; 1903 70
                XS   S         ; 1904 ec
                BZ   A190f     ; 1905 84 09
                BM   A190f     ; 1907 91 07
                LISL 3         ; 1909 6b
                AS   D         ; 190a ce
                CI   $86       ; 190b 25 86
                BC   A191e     ; 190d 82 10
;
A190f:          CLR            ; 190f 70
                XS   S         ; 1910 ec
                BZ   A1920     ; 1911 84 0e
;        *
                LI   $28       ; 1913 20 28
                BM   A1919     ; 1915 91 03
                LI   $94       ; 1917 20 94
A1919:          LR   $1,A      ; 1919 51
                CLR            ; 191a 70
                LR   $5,A      ; 191b 55
                LR   $7,A      ; 191c 57
                LR   S,A       ; 191d 5c
A191e:          BR   A1945     ; 191e 90 26
A1920:          LISL 5         ; 1920 6d
                LR   A,S       ; 1921 4c
                CI   $ff       ; 1922 25 ff
                BZ   A192c     ; 1924 84 07
                LISL 4         ; 1926 6c
                AS   I         ; 1927 cd
                CI   $35       ; 1928 25 35
                BNC  A1945     ; 192a 92 1a
;        *
A192c:          LR   A,S       ; 192c 4c
                CI   $ff       ; 192d 25 ff
                BZ   A1947     ; 192f 84 17
                LI   $5e       ; 1931 20 5e
                LISL 3         ; 1933 6b
                LR   S,A       ; 1934 5c
                LI   $ff       ; 1935 20 ff
                LISL 5         ; 1937 6d
; PAGE 61 62
                LR   S,A       ; 1938 5c
                LISU 2         ; 1939 62
                LISL 1         ; 193a 69
                LR   A,S       ; 193b 4c
                OI   $04       ; 193c 22 04
                LR   S,A       ; 193e 5c
                CLR            ; 193f 70
                LISU 5         ; 1940 65
                LISL 2         ; 1941 6a
                LR   S,A       ; 1942 5c
                LISL 4         ; 1943 6c
                LR   S,A       ; 1944 5c
A1945:          BR   A1988     ; 1945 90 42
;        *
A1947:          LISU 2         ; 1947 62
                LISL 1         ; 1948 69
                LR   A,S       ; 1949 4c
                SL   1         ; 194a 13
                LI   $28       ; 194b 20 28
                BP   A1951     ; 194d 81 03
                LI   $94       ; 194f 20 94
A1951:          LR   $1,A      ; 1951 51
;        *
                LISL 5         ; 1952 6d
                LIS  4         ; 1953 74
                LR   I,A       ; 1954 5d
                LI   $3c       ; 1955 20 3c
                LR   S,A       ; 1957 5c
;        *
                CLR            ; 1958 70
                OUTS 1         ; 1959 b1
                INS  1         ; 195a a1
                LR   $a,A      ; 195b 5a
                NI   $01       ; 195c 21 01
                BZ   A1968     ; 195e 84 09
                CLR            ; 1960 70
                XS   1         ; 1961 e1
                BM   A1968     ; 1962 91 05
                DS   1         ; 1964 31
                LR   A,1       ; 1965 41
                BR   A1972     ; 1966 90 0b
A1968:          LR   A,$a      ; 1968 4a
                NI   $04       ; 1969 21 04
                BZ   A1996     ; 196b 84 2a
                CLR            ; 196d 70
                XS   1         ; 196e e1
                BP   A1996     ; 196f 81 26
                INC            ; 1971 1f
A1972:          LR   $1,A      ; 1972 51
                LISL 1         ; 1973 69
                LR   A,S       ; 1974 4c
                OI   $80       ; 1975 22 80
                LR   S,A       ; 1977 5c
;
                LISU 5         ; 1978 65
                LISL 0         ; 1979 68
                LR   A,I       ; 197a 4d
                CI   $15       ; 197b 25 15
                BZ   A1984     ; 197d 84 06
                LR   A,S       ; 197f 4c
                CI   $15       ; 1980 25 15
                BNZ  A1996     ; 1982 94 13
A1984:          LISL 0         ; 1984 68
                CLR            ; 1985 70
                LR   I,A       ; 1986 5d
                LR   S,A       ; 1987 5c
;        *]
;        *]
;        *]
;        *
;        *MOVE BALL*
; PAGE 63 64
;        ***********
A1988:          LR   A,$0      ; 1988 40
                AS   4         ; 1989 c4
                LR   $0,A      ; 198a 50
                LR   A,$1      ; 198b 41
                LNK            ; 198c 19
                AS   5         ; 198d c5
                LR   $1,A      ; 198e 51
                LR   A,$2      ; 198f 42
                AS   6         ; 1990 c6
                LR   $2,A      ; 1991 52
                LR   A,$3      ; 1992 43
                LNK            ; 1993 19
                AS   7         ; 1994 c7
                LR   $3,A      ; 1995 53
;        *
;        *MOVE PADDLES*
;        **************
A1996:          LISU 2         ; 1996 62
                LIS  1         ; 1997 71
                LR   $a,A      ; 1998 5a
;        *
                DCI  $08fb     ; 1999 2a 08 fb
                LM             ; 199c 16
                AI   $03       ; 199d 24 03
                LR   $b,A      ; 199f 5b
;        *
                PI   A1f2b     ; 19a0 28 1f 2b
                AI   $27       ; 19a3 24 27
                CI   $45       ; 19a5 25 45
                BNC  A19ad     ; 19a7 92 05
                LI   $46       ; 19a9 20 46
                BR   A19b3     ; 19ab 90 07
A19ad:          CI   $da       ; 19ad 25 da
                BC   A19b3     ; 19af 82 03
                LI   $da       ; 19b1 20 da
A19b3:          LISL 2         ; 19b3 6a
                LR   S,A       ; 19b4 5c
;        * ]
                LI   $10       ; 19b5 20 10
                LR   $a,A      ; 19b7 5a
;        *
                DCI  $08fb     ; 19b8 2a 08 fb
                LM             ; 19bb 16
                AI   $03       ; 19bc 24 03
                LR   $b,A      ; 19be 5b
;        *
                PI   A1f2b     ; 19bf 28 1f 2b
                AI   $27       ; 19c2 24 27
                CI   $45       ; 19c4 25 45
                BNC  A19cc     ; 19c6 92 05
                LI   $46       ; 19c8 20 46
                BR   A19d2     ; 19ca 90 07
A19cc:          CI   $da       ; 19cc 25 da
                BC   A19d2     ; 19ce 82 03
                LI   $da       ; 19d0 20 da
A19d2:          LISL 3         ; 19d2 6b
                LR   S,A       ; 19d3 5c
;        *
;        *
;        *GENERATE SOUND*
;        ****************
                PI   A1ef5     ; 19d4 28 1e f5
;        *
;        *MOVE BALL BOY*
;        ***************
                LISU 5         ; 19d7 65
                LISL 2         ; 19d8 6a
; PAGE 65 66
                LR   A,I       ; 19d9 4d
                AS   S         ; 19da cc
                LR   I,A       ; 19db 5d
;
                LR   A,I       ; 19dc 4d
                AS   S         ; 19dd cc
                LR   S,A       ; 19de 5c
;        *
;        *CHECK FOR COLLISIONS*
;        **********************
;        *
;        *COURT UPPER BOUNDARY
                LR   A,$3      ; 19df 43
                CI   $38       ; 19e0 25 38
                BNC  A19e8     ; 19e2 92 05
                LI   $39       ; 19e4 20 39
                BR   A19ee     ; 19e6 90 07
;
;        *COURT BOTTOM BOUNDARY
A19e8:          CI   $e7       ; 19e8 25 e7
                BC   A19f7   ; 19ea 82 0c
                LI   $e7       ; 19ec 20 e7
A19ee:          LR   $3,A      ; 19ee 53
                PI   A1de9     ; 19ef 28 1d e9
                LI   $10       ; 19f2 20 10
                LISU 6         ; 19f4 66
                LISL 0         ; 19f5 68
                LR   S,A       ; 19f6 5c
;
;
;*BELLOW NET
A19f7:          LISL 1         ; 19f7 69
                LISU 2         ; 19f8 62
                LR   A,$1      ; 19f9 41
                CI   $5b       ; 19fa 25 5b
                BC   A1a09     ; 19fc 82 0c
                CI   $60       ; 19fe 25 60
                BNC  A1a09     ; 1a00 92 08
                LI   $f7       ; 1a02 20 f7
                NS   S         ; 1a04 fc
                OI   $08       ; 1a05 22 08
                BR   A1a0c     ; 1a07 90 04
A1a09:          LI   $f7       ; 1a09 20 f7
                NS   S         ; 1a0b fc
A1a0c:          LR   S,A       ; 1a0c 5c
;
;*IN FRONT OF PADDLE
                LISL 4         ; 1a0d 6c
                LR   A,S       ; 1a0e 4c
                NI   $9f       ; 1a0f 21 9f
                LR   S,A       ; 1a11 5c
                LR   A,$1      ; 1a12 41
                CI   $33       ; 1a13 25 33
                BC   A1a25     ; 1a15 82 0e
                CI   $5d       ; 1a17 25 5d
                BNC  A1a25     ; 1a19 92 0a
                CLR            ; 1a1b 70
                XS   5         ; 1a1c e5 -- guess
;X
;!!!
                BM   A1a24     ; 1a1d 91 06
                LR   A,S       ; 1a1f 4c
                OI   $40       ; 1a20 22 40
                BR   A1a34     ; 1a22 90 11
A1a24:          LR   A,$1      ; 1a24 41
A1a25:          CI   $5d       ; 1a25 25 5d
                BC   A1a35     ; 1a27 82 0d
                CI   $88       ; 1a29 25 88
                BNC  A1a35     ; 1a2b 92 09
                CLR            ; 1a2d 70
;PAGE 67 68
                XS   5         ; 1a2e e5
                BP   A1a35     ; 1a2f 81 05
                LR   A,S       ; 1a31 4c
                OI   $20       ; 1a32 22 20
A1a34:          LR   S,A       ; 1a34 5c
;
;*ON COURT
A1a35:          LR   A,$1      ; 1a35 41
                CI   $27       ; 1a36 25 27
                BC   A1a3e     ; 1a38 82 05
                CI   $94       ; 1a3a 25 94
                BC   A1a64     ; 1a3c 82 28
;
;*LEFT COURT BOUNDARY
A1a3e:          LISL 1         ; 1a3e 69
                CI   $07       ; 1a3f 25 07
                BNC  A1a4e     ; 1a41 92 0c 
                LR   A,S       ; 1a43 4c
                NI   $7f       ; 1a44 21 7f
                OI   $40       ; 1a46 22 40
                LR   S,A       ; 1a48 5c
                LI   $08       ; 1a49 20 08
                LR   $1,A      ; 1a4b 51
                BR   A1a5b     ; 1a4c 90 0f
;
;*RIGHT COURT BOUNDARY
A1a4e:          CI   $B4       ; 1a4e 25 B4 -- guess
                BC   A1a67     ; 1a50 82 16
                LR   A,S       ; 1a52 4c
                NI   $7f       ; 1a53 21 7f
                NI   $bf       ; 1a55 21 bf
                LR   S,A       ; 1a57 5c
                LI   $b4       ; 1a58 20 b4
                LR   $1,A      ; 1a5a 51
A1a5b:          LISL 0         ; 1a5b 68
                LISU 5         ; 1a5c 65
                LI   $67       ; 1a5d 20 67
                ASD  S         ; 1a5f dc
                LR   S,A       ; 1a60 5c
                LIS  4         ; 1a61 74
                LISU 6         ; 1a62 66
                LISL 0         ; 1a63 68
A1a64:          LR   S,A       ; 1a64 5c
                BR   A1ac6     ; 1a65 90 60
;
;        *BEYOND LEFT PADDLE
A1a67:          CI   $1c       ; 1a67 25 1c
                BC   A1ac6     ; 1a69 82 5c
;
                CI   $9f       ; 1a6b 25 9f
                BNC  A1ac6     ; 1a6d 92 58
;
;        *BALL IN PADDLE REGION
                COM            ; 1a6f 18
                LISL 2         ; 1a70 6a
                BM   A1a74     ; 1a71 91 02
                LISL 3         ; 1a73 6b
;
;        *BALL ABOVE PADDLE
A1a74:          LR   A,$3      ; 1a74 43
                COM            ; 1a75 18
                AI   $ed       ; 1a76 24 ed
                AS   S         ; 1a78 cc
                BC   A1ac6     ; 1a79 82 4c
;
;*BALL BELLOW PADDLE
                LR   A,S       ; 1a7b 4c
                COM            ; 1a7c 18
;PAGE 69 70
                AI   $ed       ; 1a7d 24 ed
                AS   3         ; 1a7f c3
                BC   A1ac6     ; 1a80 82 45
;
;*SIDE COLLISION--TOP OF PADDLE
                LR   A,$3      ; 1a82 43
                COM            ; 1a83 18
                AI   $ee       ; 1a84 24 ee
                AS   S         ; 1a86 cc
                BNC  A1a9b     ; 1a87 92 13
                CLR            ; 1a89 70
                XS   7         ; 1a8a e7
                BM   A1a9b     ; 1a8b 91 0f
                BZ   A1a9b     ; 1a8d 84 0d
                LR   A,S       ; 1a8f 4c
                CI   $4b       ; 1a90 25 4b
                BNC  A1a97     ; 1a92 92 04
                LI   $4c       ; 1a94 20 4c
                LR   S,A       ; 1a96 5c
A1a97:          AI   $ed       ; 1a97 24 ed
                BR   A1ab0     ; 1a99 90 16
;
;*SIDE COLLISION--BOTTOM OF PADLE
A1a9b:          LR   A,S       ; 1a9b 4c
                COM            ; 1a9c 18
                AI   $ee       ; 1a9d 24 ee
                AS   3         ; 1a9f c3
                BNC  A1ab6     ; 1aa0 92 15
                CLR            ; 1aa2 70
                XS   7         ; 1aa3 e7
                BP   A1ab6     ; 1aa4 81 11
                LR   A,S       ; 1aa6 4c
                CI   $d4       ; 1aa7 25 d4
                BC   A1aae     ; 1aa9 82 04
                LI   $d4       ; 1aab 20 d4
                LR   S,A       ; 1aad 5c
A1aae:          AI   $13       ; 1aae 24 13
A1ab0:          LR   $3,A      ; 1ab0 53
                PI   A1de9     ; 1ab1 28 1d e9
;
                BR   A1b0f     ; 1ab4 90 5a
;
;*THROUGH LEFT PADDLE
A1ab6:          LR   A,$1      ; 1ab6 41
                CI   $21       ; 1ab7 25 21
                BNC  A1abf     ; 1ab9 92 05
                LI   $1c       ; 1abb 20 1c
                BR   A1ac5     ; 1abd 90 07
;
;*THROUGH RIGHT PADDLE
A1abf:          CI   $9a       ; 1abf 25 9a
                BC   A1ac8     ; 1ac1 82 06
                LI   $a0       ; 1ac3 20 a0
A1ac5:          LR   $1,A      ; 1ac5 51
A1ac6:          BR   A1b22     ; 1ac6 90 5b
;        *
;        *FRONT HIT
A1ac8:          LIS  5         ; 1ac8 75
                LR   $a,A      ; 1ac9 5a
                LR   A,S       ; 1aca 4c
                COM            ; 1acb 18
                AS   3         ; 1acc c3
                AI   $ed       ; 1acd 24 ed
A1acf:          DS   $a        ; 1acf 3a
                AI   $08       ; 1ad0 24 08
                BM   A1acf     ; 1ad2 91 fc
                DCI  $1200     ; 1ad4 2a 12 00
;PAGE 71 72
                CLR            ; 1ad7 70
                XS   $a        ; 1ad8 ea
                CI   $02       ; 1ad9 25 02
                BNZ  A1ae2     ; 1adb 94 06
                CLR            ; 1add 70
                LR   $6,A      ; 1ade 56
                LR   $7,A      ; 1adf 57
                BR   A1af8     ; 1ae0 90 17
A1ae2:          BNC  A1aef     ; 1ae2 92 0c
                SL   1         ; 1ae4 13
                ADC            ; 1ae5 8e
                LM             ; 1ae6 16
                LR   $6,A      ; 1ae7 56
                LM             ; 1ae8 16
                LR   $7,A      ; 1ae9 57
                PI   A1de9     ; 1aea 28 1d e9
                BR   A1af8     ; 1aed 90 0a
A1aef:          COM            ; 1aef 18
                AI   $05       ; 1af0 24 05
                SL   1         ; 1af2 13
                ADC            ; 1af3 8e -- guess
                LM             ; 1af4 16
                LR   $6,A      ; 1af5 56
                LM             ; 1af6 16
                LR   $7,A      ; 1af7 57
A1af8:          CLR            ; 1af8 70
                XS   1         ; 1af9 e1
                BM   A1b06     ; 1afa 91 0b
                LI   $80       ; 1afc 20 80
                LR   $4,A      ; 1afe 54
                LI   $01       ; 1aff 20 01
                LR   $5,A      ; 1b01 55
                LI   $28       ; 1b02 20 28
                BR   A1b0e     ; 1b04 90 09
A1b06:          LI   $80       ; 1b06 20 80
                LR   $4,A      ; 1b08 54
                LI   $fe       ; 1b09 20 fe
                LR   $5,A      ; 1b0b 55
                LI   $94       ; 1b0c 20 94
A1b0e:          LR   $1,A      ; 1b0e 51
;        *
A1b0f:          LIS  8         ; 1b0f 78
                LISU 6         ; 1b10 66
                LISL 0         ; 1b11 68
                LR   S,A       ; 1b12 5c
                LISL 5         ; 1b13 6d
                LISU 2         ; 1b14 62
                DS   S         ; 1b15 3c
                BNZ  A1b22     ; 1b16 94 0b
                LIS  1         ; 1b18 71
                LR   S,A       ; 1b19 5c
                LIS  4         ; 1b1a 74
                LR   IS,A       ; 1b1b 0b
                PI   A1df5     ; 1b1c 28 1d f5
                PI   A1df5     ; 1b1f 28 1d f5
;        *
;        *
;        *
;        *OUTPUT*
;        ********
;        *
;        *CHOOSE BALL & NET IMAGES
A1b22:          LR   A,$1      ; 1b22 41
                CI   $21       ; 1b23 25 21
                BNC  A1b2b     ; 1b25 92 05
                LI   $00       ; 1b27 20 00
                BR   A1b4d     ; 1b29 90 23
A1b2b:          CI   $2b       ; 1b2b 25 2b
                BNC  A1b33     ; 1b2d 92 05
;PAGE 73 74
                LI   $20       ; 1b2f 20 20
                BR   A1b4d     ; 1b31 90 1b
A1b33:          CI   $5e       ; 1b33 25 5e
                BNC  A1b3b     ; 1b35 92 05
                LI   $00       ; 1b37 20 00
                BR   A1b4d     ; 1b39 90 13
A1b3b:          CI   $90       ; 1b3b 25 90
                BNC  A1b43     ; 1b3d 92 05
                LI   $30       ; 1b3f 20 30
                BR   A1b4d     ; 1b41 90 0b
A1b43:          CI   $9a       ; 1b43 25 9a
                BNC  A1b4b     ; 1b45 92 05
                LI   $10       ; 1b47 20 10
                BR   A1b4d     ; 1b49 90 03
A1b4b:          LI   $30       ; 1b4b 20 30
A1b4d:          LISL 1         ; 1b4d 69
                LISU 2         ; 1b4e 62
                LR   $a,A      ; 1b4f 5a
                LR   A,S       ; 1b50 4c -- guess
                NI   $cf       ; 1b51 21 cf
                XS   $a        ; 1b53 ea
                LR   S,A       ; 1b54 5c
;        *
;        *UPDATE ROM POINTERS, X-VALUES & DELTA-X
                LISL 1         ; 1b55 69
                LISU 2         ; 1b56 62
                LR   A,S       ; 1b57 4c
                NI   $20       ; 1b58 21 20
;
                LI   $dd       ; 1b5a 20 dd
                BNZ  A1b60     ; 1b5c 94 03
                LI   $e3       ; 1b5e 20 e3
A1b60:          DCI  $0c83     ; 1b60 2a 0c 83
                ST             ; 1b63 17
                DCI  $0c49     ; 1b64 2a 0c 49
                ST             ; 1b67 17
;
                LI   $f2       ; 1b68 20 f2
                BNZ  A1b6e     ; 1b6a 94 03
                LI   $f2       ; 1b6c 20 f2
A1b6e:          DCI  $0c91     ; 1b6e 2a 0c 91
                ST             ; 1b71 17
                DCI  $0c57     ; 1b72 2a 0c 57
                ST             ; 1b75 17
;
                LI   $fe       ; 1b76 20 fe
                BNZ  A1b7c     ; 1b78 94 03
                LI   $fa       ; 1b7a 20 fa
A1b7c:          AS   1         ; 1b7c c1
                DCI  $0c39     ; 1b7d 2a 0c 39
                ST             ; 1b80 17
;
                LISL 4         ; 1b81 6c
                LR   A,S       ; 1b82 4c
                NI   $40       ; 1b83 21 40
                LI   $09       ; 1b85 20 09
                BZ   A1b8b     ; 1b87 84 03
                LI   $69       ; 1b89 20 69
A1b8b:          DCI  $0c84     ; 1b8b 2a 0c 84
                ST             ; 1b8e 17
                LI   $e9       ; 1b8f 20 e9
                BZ   A1b95     ; 1b91 84 03
                LI   $29       ; 1b93 20 29
A1b95:          DCI  $0c4a     ; 1b95 2a 0c 4a
                ST             ; 1b98 17
                LI   $d3       ; 1b99 20 d3
                BZ   A1b9f     ; 1b9b 84 03
                LI   $d3       ; 1b9d 20 d3
A1b9f:          DCI  $0c92     ; 1b9f 2a 0c 92
;PAGE 75 76
                ST             ; 1ba2 17
                LI   $d2       ; 1ba3 20 d2
                BZ   A1ba9     ; 1ba5 84 03
                LI   $d3       ; 1ba7 20 d3
A1ba9:          DCI  $0c58     ; 1ba9 2a 0c 58
                ST             ; 1bac 17
                LI   $41       ; 1bad 20 41
                BZ   A1bb3     ; 1baf 84 03
                LI   $42       ; 1bb1 20 42
A1bb3:          DCI  $0c1e     ; 1bb3 2a 0c 1e
                ST             ; 1bb6 17
                LR   A,S       ; 1bb7 4c
                NI   $20       ; 1bb8 21 20
                LI   $c9       ; 1bba 20 c9
                BZ   A1bc0     ; 1bbc 84 03
                LI   $29       ; 1bbe 20 29
A1bc0:          DCI  $0c85     ; 1bc0 2a 0c 85
                ST             ; 1bc3 17
                LI   $a9       ; 1bc4 20 a9
                BZ   A1bca     ; 1bc6 84 03
                LI   $e9       ; 1bc8 20 e9
A1bca:          DCI  $0c4b     ; 1bca 2a 0c 4b
                ST             ; 1bcd 17
                LI   $33       ; 1bce 20 33
                BZ   A1bd4     ; 1bd0 84 03
                LI   $34       ; 1bd2 20 34
A1bd4:          DCI  $0c93     ; 1bd4 2a 0c 93
                ST             ; 1bd7 17
                LI   $33       ; 1bd8 20 33
                BZ   A1bde     ; 1bda 84 03
                LI   $33       ; 1bdc 20 33
A1bde:          DCI  $0c59     ; 1bde 2a 0c 59
                ST             ; 1be1 17
                LI   $96       ; 1be2 20 96
                BZ   A1be8     ; 1be4 84 03
                LI   $8e       ; 1be6 20 8e
A1be8:          DCI  $0c3b     ; 1be8 2a 0c 3b
                ST             ; 1beb 17
                LI   $41       ; 1bec 20 41
                BZ   A1bf2     ; 1bee 84 03
                LI   $42       ; 1bf0 20 42
A1bf2:          DCI  $0c1f     ; 1bf2 2a 0c 1f
                ST             ; 1bf5 17
;
                LISL 1         ; 1bf6 69
                LR   A,S       ; 1bf7 4c
                NI   $10       ; 1bf8 21 10
;
                LI   $69       ; 1bfa 20 69
                BZ   A1c00     ; 1bfc 84 03
                LI   $a5       ; 1bfe 20 a5
A1c00:          DCI  $0c86     ; 1c00 2a 0c 86
                ST             ; 1c03 17
                ST             ; 1c04 17
                ST             ; 1c05 17
                DCI  $0c4c     ; 1c06 2a 0c 4c
                ST             ; 1c09 17
                ST             ; 1c0a 17
                ST             ; 1c0b 17
;
                LI   $f4       ; 1c0c 20 f4
                BZ   A1c12     ; 1c0e 84 03
                LI   $f4       ; 1c10 20 f4
A1c12:          DCI  $0c94     ; 1c12 2a 0c 94
                ST             ; 1c15 17
                ST             ; 1c16 17
                ST             ; 1c17 17
                DCI  $0c5a     ; 1c18 2a 0c 5a
;PAGE 77 78
                ST             ; 1c1b 17
                ST             ; 1c1c 17
                ST             ; 1c1d 17
;
                LI   $ff       ; 1c1e 20 ff
                BZ   A1c24     ; 1c20 84 03
                LI   $f9       ; 1c22 20 f9
A1c24:          AI   $5e       ; 1c24 24 5e
                DCI  $0c3c     ; 1c26 2a 0c 3c
                ST             ; 1c29 17
                ST             ; 1c2a 17
                ST             ; 1c2b 17
;
                LR   A,S       ; 1c2c 4c
                SR   1         ; 1c2d 12
                SR   4         ; 1c2e 14
                NI   $02       ; 1c2f 21 02
                LR   $a,A      ; 1c31 5a
                LR   A,S       ; 1c32 4c
                SR   1         ; 1c33 12
                NI   $01       ; 1c34 21 01
                AS   $a        ; 1c36 ca
                SL   1         ; 1c37 13
                SL   1         ; 1c38 13
                DCI  $1204     ; 1c39 2a 12 04
                ADC            ; 1c3c 8e
                LM             ; 1c3d 16
                XDC            ; 1c3e 2c
                DCI  $0c9b     ; 1c3f 2a 0c 9b
                ST             ; 1c42 17 -- guess
                XDC            ; 1c43 2c
                LM             ; 1c44 16
                XDC            ; 1c45 2c
                DCI  $0c8d     ; 1c46 2a 0c 8d
                ST             ; 1c49 17
                XDC            ; 1c4a 2c
                LM             ; 1c4b 16
                XDC            ; 1c4c 2c
                DCI  $0c61     ; 1c4d 2a 0c 61
                ST             ; 1c50 17
                XDC            ; 1c51 2c
                LM             ; 1c52 16
                DCI  $0c53     ; 1c53 2a 0c 53
                ST             ; 1c56 17
;
                LISL 7         ; 1c57 6f
                DS   S         ; 1c58 3c
                BNZ  A1c62     ; 1c59 94 08
                LIS  7         ; 1c5b 77
                LR   S,A       ; 1c5c 5c
                LI   $02       ; 1c5d 20 02
                LISL 1         ; 1c5f 69
                XS   S         ; 1c60 ec
                LR   S,A       ; 1c61 5c
;
;
A1c62:          LI   $f8       ; 1c62 20 f8
                LISU 5         ; 1c64 65
                LISL 3         ; 1c65 6b
                AS   S         ; 1c66 cc
                DCI  $0c43     ; 1c67 2a 0c 43
                ST             ; 1c6a 17
;
                LR   A,$1      ; 1c6b 41
                CI   $5e       ; 1c6c 25 5e
;
                LI   $f1       ; 1c6e 20 f1
                BC   A1c74     ; 1c70 82 03
                LI   $09       ; 1c72 20 09
;PAGE 79 80
A1c74:          DCI  $0c8e     ; 1c74 2a 0c 8e
                ST             ; 1c77 17
                ST             ; 1c78 17
                LI   $e5       ; 1c79 20 e5
                BC   A1c7f     ; 1c7b 82 03
                LI   $fd       ; 1c7d 20 fd
A1c7f:          DCI  $0c54     ; 1c7f 2a 0c 54
                ST             ; 1c82 17
                ST             ; 1c83 17
;
                LI   $d6       ; 1c84 20 d6
                BC   A1c8a     ; 1c86 82 03
                LI   $d7       ; 1c88 20 d7
A1c8a:          DCI  $0c9c     ; 1c8a 2a 0c 9c
                ST             ; 1c8d 17
                LI   $36       ; 1c8e 20 36
                BC   A1c94     ; 1c90 82 03
                LI   $37       ; 1c92 20 37
A1c94:          ST             ; 1c94 17
                LI   $d6       ; 1c95 20 d6
                BC   A1c9b     ; 1c97 82 03
                LI   $d6       ; 1c99 20 d6
A1c9b:          DCI  $0c62     ; 1c9b 2a 0c 62
                ST             ; 1c9e 17 -- guess
                LI   $36       ; 1c9f 20 36 -- guess
                BC   A1ca5     ; 1ca1 82 03
                LI   $36       ; 1ca3 20 36
A1ca5:          ST             ; 1ca5 17
;
;*SELECT INACTIVE LIST
                LISU 2         ; 1ca6 62
                LISL 0         ; 1ca7 68
                LR   A,S       ; 1ca8 4c
                NI   $40       ; 1ca9 21 40
                DCI  $0870     ; 1cab 2a 08 70
                BZ   A1cb3     ; 1cae 84 04
                DCI  $0880     ; 1cb0 2a 08 80
A1cb3:          LR   Q,DC      ; 1cb3 0e
;
;*COPY ACTIVE LIST INTO INACTIVE
                DCI  $0860     ; 1cb4 2a 08 60
                XDC            ; 1cb7 2c
                DCI  $0850     ; 1cb8 2a 08 50
                LISU 3         ; 1cbb 63
                LISL 0         ; 1cbc 68
                XDC            ; 1cbd 2c 
                LI   $0d       ; 1cbe 20 0d
                LR   $a,A      ; 1cc0 5a
                PI   A1dd1     ; 1cc1 28 1d d1
                LI   $13       ; 1cc4 20 13
                ADC            ; 1cc6 8e
                XDC            ; 1cc7 2c
                ADC            ; 1cc8 8e
                XDC            ; 1cc9 2c
                LI   $0d       ; 1cca 20 0d
                LR   $a,A      ; 1ccc 5a
                PI   A1dd1     ; 1ccd 28 1d d1
;
;*SORT INACTIVE LIST
A1cd0:          LIS  $a        ; 1cd0 7a
                AI   $18       ; 1cd1 24 18
                LR   IS,A       ; 1cd3 0b
                LR   DC,Q      ; 1cd4 0f
                LR   A,S       ; 1cd5 4c
                AI   $ff       ; 1cd6 24 ff
                ADC            ; 1cd8 8e
                PI   A1e03     ; 1cd9 28 1e 03
                BR   A1ce3     ; 1cdc 90 06
                PI   A1e24     ; 1cde 28 1e 24
                BR   A1cd0     ; 1ce1 90 ee
A1ce3:          LIS  $a        ; 1ce3 7a
;PAGE 81 82
                AI   $18       ; 1ce4 24 18
                LR   IS,A       ; 1ce6 0b
                LR   DC,Q      ; 1ce7 0f
                LR   A,S       ; 1ce8 4c
                ADC            ; 1ce9 8e
                PI   A1e03     ; 1cea 28 1e 03
                BR   A1cf4     ; 1ced 90 06
                PI   A1e24     ; 1cef 28 1e 24
                BR   A1ce3     ; 1cf2 90 f0
;
;
A1cf4:          LI   $18       ; 1cf4 20 18
                LR   IS,A       ; 1cf6 0b
                LR   DC,Q      ; 1cf7 0f
                CLR            ; 1cf8 70
                XS   S         ; 1cf9 ec
                BZ   A1d09     ; 1cfa 84 0e
                AI   $ff       ; 1cfc 24 ff
                ADC            ; 1cfe 8e
                PI   A1e03     ; 1cff 28 1e 03
                BR   A1d09     ; 1d02 90 06
                PI   A1e24     ; 1d04 28 1e 24
                BR   A1cf4     ; 1d07 90 ec
A1d09:          LI   $18       ; 1d09 20 18
                LR   IS,A       ; 1d0b 0b
                LR   DC,Q      ; 1d0c 0f
                LR   A,S       ; 1d0d 4c
                CI   $0b       ; 1d0e 25 0b
                BNC  A1d1d     ; 1d10 92 0c
                ADC            ; 1d12 8e
                PI   A1e03     ; 1d13 28 1e 03
                BR   A1d1d     ; 1d16 90 06
                PI   A1e24     ; 1d18 28 1e 24
                BR   A1d09     ; 1d1b 90 ed
;
;
;*UPDATE Y-VALUES
A1d1d:          LISU 3         ; 1d1d 63
                LISL 0         ; 1d1e 68
                LR   A,I       ; 1d1f 4d
                LR   DC,Q      ; 1d20 0f
                ADC            ; 1d21 8e
                XDC            ; 1d22 2c
                LR   DC,Q      ; 1d23 0f
                ADC            ; 1d24 8e
                LISU 2         ; 1d25 62
                LR   A,D       ; 1d26 4e
                NI   $08       ; 1d27 21 08
                LM             ; 1d29 16
                BZ   A1d30     ; 1d2a 84 05
                OI   $80       ; 1d2c 22 80
                BR   A1d32     ; 1d2e 90 03
A1d30:          NI   $7f       ; 1d30 21 7f
A1d32:          XDC            ; 1d32 2c
                ST             ; 1d33 17
;
                LISU 4         ; 1d34 64
                LR   A,I       ; 1d35 4d
                LR   DC,Q      ; 1d36 0f
                ADC            ; 1d37 8e
                XDC            ; 1d38 2c
                LR   DC,Q      ; 1d39 0f
                ADC            ; 1d3a 8e
                LISU 2         ; 1d3b 62
                CLR            ; 1d3c 70
                XS   S         ; 1d3d ec
                LM             ; 1d3e 16
;PAGE 83 84
                BM   A1d45     ; 1d3f 91 05
                NI   $7f       ; 1d41 21 7f
                BR   A1d47     ; 1d43 90 03 -- guess
A1d45:          OI   $80       ; 1d45 22 80
A1d47:          XDC            ; 1d47 2c
                ST             ; 1d48 17
;
                LISU 4         ; 1d49 64
                LR   A,S       ; 1d4a 4c
                LR   DC,Q      ; 1d4b 0f
                ADC            ; 1d4c 8e
                XDC            ; 1d4d 2c
                LR   DC,Q      ; 1d4e 0f
                ADC            ; 1d4f 8e
                LISU 2         ; 1d50 62
                CLR            ; 1d51 70
                XS   D         ; 1d52 ee
                LM             ; 1d53 16
                BM   A1d5a     ; 1d54 91 05
                NI   $7f       ; 1d56 21 7f
                BR   A1d5c     ; 1d58 90 03
A1d5a:          OI   $80       ; 1d5a 22 80
A1d5c:          XDC            ; 1d5c 2c
                ST             ; 1d5d 17
;
                LISU 4         ; 1d5e 64
                LISL 2         ; 1d5f 6a
                LR   A,D       ; 1d60 4e
                LR   DC,Q      ; 1d61 0f
                ADC            ; 1d62 8e
                XDC            ; 1d63 2c
                LR   DC,Q      ; 1d64 0f
                ADC            ; 1d65 8e
                LISU 2         ; 1d66 62
                LR   A,S       ; 1d67 4c
                NI   $04       ; 1d68 21 04
                LM             ; 1d6a 16
                BZ   A1d71     ; 1d6b 84 05
                OI   $80       ; 1d6d 22 80
                BR   A1d73     ; 1d6f 90 03
A1d71:          NI   $7f       ; 1d71 21 7f -- guess
A1d73:          XDC            ; 1d73 2c
                ST             ; 1d74 17
;
                LR   DC,Q      ; 1d75 0f
                LI   $e0       ; 1d76 20 e0
                ADC            ; 1d78 8e
                LR   Q,DC      ; 1d79 0e
                LISU 3         ; 1d7a 63
                LISL 0         ; 1d7b 68
                LR   A,I       ; 1d7c 4d
                ADC            ; 1d7d 8e
                LI   $fd       ; 1d7e 20 fd
                AS   3         ; 1d80 c3
                ST             ; 1d81 17
                LR   DC,Q      ; 1d82 0f
                LR   A,S       ; 1d83 4c
                ADC            ; 1d84 8e
                LISU 2         ; 1d85 62
                LISL 2         ; 1d86 6a
                LI   $f1       ; 1d87 20 f1
                AS   S         ; 1d89 cc
                ST             ; 1d8a 17
                LR   DC,Q      ; 1d8b 0f
                LISU 3         ; 1d8c 63
                LISL 2         ; 1d8d 6a
                LR   A,S       ; 1d8e 4c
                ADC            ; 1d8f 8e
                LISU 2         ; 1d90 62
                LISL 3         ; 1d91 6b
;PAGE 85 86
                LI   $f1       ; 1d92 20 f1
                AS   S         ; 1d94 cc
                ST             ; 1d95 17 -- guess
                LR   DC,Q      ; 1d96 0f
                LISU 4         ; 1d97 64
                LISL 2         ; 1d98 6a
                LR   A,S       ; 1d99 4c
                ADC            ; 1d9a 8e
                LISU 5         ; 1d9b 65
                LISL 5         ; 1d9c 6d
                LR   A,S       ; 1d9d 4c
                ST             ; 1d9e 17
;
;*RED BACKGROUND BELLOW COURT
                LI   $ec       ; 1d9f 20 ec
                LR   $a,A      ; 1da1 5a
                PI   A1de0     ; 1da2 28 1d e0
                DCI  $08f5     ; 1da5 2a 08 f5
                LI   $01       ; 1da8 20 01
                ST             ; 1daa 17
;
;*UPDATE DEL-Y & ROM POINTERS
                DCI  $0c1c     ; 1dab 2a 0c 1c
;
;*SWITCH LISTS
                PI   A1e50     ; 1dae 28 1e 50 -- guess
                LISU 2         ; 1db1 62
                LISL 0         ; 1db2 68
                LR   A,S       ; 1db3 4c
                XI   $40       ; 1db4 23 40
                LR   S,A       ; 1db6 5c
                DCI  $08f7     ; 1db7 2a 08 f7
                ST             ; 1dba 17
;*
;*FRAME COMPUTED & DISPLAYED
;*       NOP             FOR BREAKPOINT
;*       NOP
;*       NOP
;*       NOP
;*
;*GREEN BACKGROUND FOR COURT
                LI   $34       ; 1dbb 20 34
                LR   $a,A      ; 1dbd 5a
                PI   A1de0     ; 1dbe 28 1d e0
                DCI  $08f5     ; 1dc1 2a 08 f5
                LI   $02       ; 1dc4 20 02
                ST             ; 1dc6 17
;
                JMP  A1877     ; 1dc7 29 18 77
;        *
;        *
;        *******************************************
;        *                                         *
;        *     MAIN PROGRAM                        *
;        *                                         *
;        *******************************************
;        *
;        *
;        *CLEAR UM-1 REGISTERS*
;        **********************
A1dca:          LI   $ff       ; 1dca 20 ff
A1dcc:          ST             ; 1dcc 17
                DS   $a        ; 1dcd 3a
                BNZ  A1dcc     ; 1dce 94 fd
                POP            ; 1dd0 1c
;        *
;        *MOVE DATA IN MEMORY*
;        *********************
A1dd1:          LR   K,P       ; 1dd1 08
;PAGE 87 88
A1dd2:          LM             ; 1dd2 16
                XDC            ; 1dd3 2c
                ST             ; 1dd4 17
                XDC            ; 1dd5 2c
                DS   $a        ; 1dd6 3a
                BNZ  A1dd2     ; 1dd7 94 fa
                PK             ; 1dd9 0c
;        *
;        *ZERO MEMORY*
;        *************
A1dda:          CLR            ; 1dda 70
A1ddb:          ST             ; 1ddb 17
                DS   $a        ; 1ddc 3a
                BNZ  A1ddb     ; 1ddd 94 fd
                POP            ; 1ddf 1c
;        *
;        *SYNC ON A GIVEN LINE .GT. 7*
;        *****************************
A1de0:          LR   K,P       ; 1de0 08
                LR   A,$a      ; 1de1 4a
A1de2:          DCI  $08fb     ; 1de2 2a 08 fb
                CM             ; 1de5 8d
                BNZ  A1de2     ; 1de6 94 fb
                PK             ; 1de8 0c
;        *
;VY*  TRASHED LISTING
;        ***********
A1de9:          LR   K,P       ; 1de9 08
                LR   A,$6      ; 1dea 46
                COM            ; 1deb 18
                INC            ; 1dec 1f
                LR   J,W       ; 1ded 1e
                LR   $6,A      ; 1dee 56
                LR   A,$7      ; 1def 47
                COM            ; 1df0 18
                LR   W,J       ; 1df1 1d
                LNK            ; 1df2 19
                LR   $7,A      ; 1df3 57
                PK             ; 1df4 0c
;        *
;        *MULTIPLY BY 2*
;        ***************
A1df5:          LR   K,P       ; 1df5 08
                CLR            ; 1df6 70
                XS   S         ; 1df7 ec
                LR   J,W       ; 1df8 1e
                SL   1         ; 1df9 13
                LR   I,A       ; 1dfa 5d
                LR   A,S       ; 1dfb 4c
                SL   1         ; 1dfc 13
                LR   W,J       ; 1dfd 1d
                BP   A1e01     ; 1dfe 81 02
                INC            ; 1e00 1f
A1e01:          LR   I,A       ; 1e01 5d
                PK             ; 1e02 0c
;        *
;        *COMPARE X-VALUE ENTRIES*
;        *************************
A1e03:          LR   K,P       ; 1e03 08
                LM             ; 1e04 16
                NI   $0f       ; 1e05 21 0f
                XDC            ; 1e07 2c
                DCI  $0c39     ; 1e08 2a 0c 39
                ADC            ; 1e0b 8e
                LM             ; 1e0c 16
                LR   $a,A      ; 1e0d 5a
                XDC            ; 1e0e 2c
                LM             ; 1e0f 16
;PAGE 89 90
                NI   $0f       ; 1e10 21 0f
                XDC            ; 1e12 2c
                DCI  $0c39     ; 1e13 2a 0c 39
                ADC            ; 1e16 8e
                LR   A,$a      ; 1e17 4a
                CM             ; 1e18 8d
                XDC            ; 1e19 2c
                BC   A1e23     ; 1e1a 82 08
                LR   A,KL      ; 1e1c 01
                AI   $02       ; 1e1d 24 02
                LR   KL,A      ; 1e1f 05
                LR   A,KU      ; 1e20 00
                LNK            ; 1e21 19
                LR   KU,A      ; 1e22 04
A1e23:          PK             ; 1e23 0c
;        *
;        *EXCHANGE X-ORDER & Y-VALUE ENTRIES*
;        ************************************
A1e24:          LR   K,P       ; 1e24 08
                LI   $fe       ; 1e25 20 fe
                ADC            ; 1e27 8e
                LR   H,DC      ; 1e28 11
                XDC            ; 1e29 2c
                LR   DC,H      ; 1e2a 10
                LM             ; 1e2b 16
                LR   $a,A      ; 1e2c 5a
                LM             ; 1e2d 16
                XDC            ; 1e2e 2c
                ST             ; 1e2f 17
;        *
                AI   $18       ; 1e30 24 18
                LR   IS,A       ; 1e32 0b
                LI   $ff       ; 1e33 20 ff
                AS   S         ; 1e35 cc
                LR   S,A       ; 1e36 5c
;        *
                LR   A,$a      ; 1e37 4a
                ST             ; 1e38 17
;        *
                AI   $18       ; 1e39 24 18
                LR   IS,A       ; 1e3b 0b
                LIS  1         ; 1e3c 71
                AS   S         ; 1e3d cc
                LR   S,A       ; 1e3e 5c
                LI   $de       ; 1e3f 20 de
                ADC            ; 1e41 8e
                LR   H,DC      ; 1e42 11
                XDC            ; 1e43 2c
                LR   DC,H      ; 1e44 10
                LM             ; 1e45 16
                LR   $a,A      ; 1e46 5a -- guess
                LM             ; 1e47 16
                XDC            ; 1e48 2c
                ST             ; 1e49 17
                LR   A,$a      ; 1e4a 4a
                ST             ; 1e4b 17
                LI   $20       ; 1e4c 20 20
                ADC            ; 1e4e 8e
                PK             ; 1e4f 0c
;        *
;        *UPDATE ROUTINE*
;        ****************
A1e50:          LR   K,P       ; 1e50 08
                LISU 2         ; 1e51 62
                LISL 4         ; 1e52 6c
                XDC            ; 1e53 2c
                LI   $f0       ; 1e54 20 f0
A1e56:          DCI  $08fb     ; 1e56 2a 08 fb
                CM             ; 1e59 8d
;PAGE 91 92
                BNZ  A1e56     ; 1e5a 94 fb
                XDC            ; 1e5c 2c
;        *
A1e5d:          LM             ; 1e5d 16
                LR   $a,A      ; 1e5e 5a
                CI   $ff       ; 1e5f 25 ff
                BNZ  A1e68     ; 1e61 94 06
                LR   A,S       ; 1e63 4c
                OI   $80       ; 1e64 22 80
                LR   S,A       ; 1e66 5c
                PK             ; 1e67 0c
A1e68:          CI   $fe       ; 1e68 25 fe
                BNZ  A1e71     ; 1e6a 94 06
                CLR            ; 1e6c 70
                XS   S         ; 1e6d ec
                BP   A1e5d     ; 1e6e 81 ee
                PK             ; 1e70 0c
A1e71:          LR   A,$a      ; 1e71 4a
                CI   $fd       ; 1e72 25 fd
                BNZ  A1e83     ; 1e74 94 0e
                XDC            ; 1e76 2c
                DCI  $08fa     ; 1e77 2a 08 fa
                LM             ; 1e7a 16
                NS   S         ; 1e7b fc
                XDC            ; 1e7c 2c
                ST             ; 1e7d 17 -- guess
                BP   A1e81     ; 1e7e 81 02
                ADC            ; 1e80 8e
A1e81:          BR   A1e5d     ; 1e81 90 db
A1e83:          LR   A,$a      ; 1e83 4a
                XDC            ; 1e84 2c
                DCI  $0800     ; 1e85 2a 08 00
                ADC            ; 1e88 8e
                XDC            ; 1e89 2c
                LI   $0d       ; 1e8a 20 0d
                LR   $a,A      ; 1e8c 5a
A1e8d:          LM             ; 1e8d 16
                XDC            ; 1e8e 2c
                ST             ; 1e8f 17
                XDC            ; 1e90 2c
                DS   $a        ; 1e91 3a
                BNZ  A1e8d     ; 1e92 94 fa
                BR   A1e5d     ; 1e94 90 c8
;        *
;        *MOVE SCORE DIGIT SUBROUTINE*
;        *****************************
A1e96:          LR   K,P       ; 1e96 08
                XDC            ; 1e97 2c
                DCI  $120d     ; 1e98 2a 12 0d
                LR   A,$a      ; 1e9b 4a
                INC            ; 1e9c 1f
                LR   $a,A      ; 1e9d 5a
                LI   $07       ; 1e9e 20 07
A1ea0:          ADC            ; 1ea0 8e
                DS   $a        ; 1ea1 3a
                BNZ  A1ea0     ; 1ea2 94 fd
                LI   $07       ; 1ea4 20 07
                LR   $a,A      ; 1ea6 5a -- guess
A1ea7:          LM             ; 1ea7 16
                XDC            ; 1ea8 2c
                ST             ; 1ea9 17
                LIS  1         ; 1eaa 71
                ADC            ; 1eab 8e
                XDC            ; 1eac 2C
                DS   $a        ; 1ead 3a
                BNZ  A1ea7     ; 1eae 94 f8
                PK             ; 1eb0 0c
;        *
;        *SOUND GENERATION ROUTINES*
;        ***************************
;PAGE 93 94
;        *
;        *
                LR   $8,A      ; 1eb1 58
                LR   A,IS      ; 1eb2 0a -- guess
                LISU 7         ; 1eb3 67
                LISL 0         ; 1eb4 68
                LR   I,A       ; 1eb5 5d
                LR   A,$9      ; 1eb6 49
                LR   I,A       ; 1eb7 5d
                LR   J,W       ; 1eb8 1e
                LR   A,$a      ; 1eb9 4a
                LR   I,A       ; 1eba 5d
                LR   A,HL      ; 1ebb 4b -- guess
                LR   S,A       ; 1ebc 5c
                LR   H,DC      ; 1ebd 11
;        *
                LISU 6         ; 1ebe 66
                LISL 1         ; 1ebf 69
                DS   I         ; 1ec0 3d
                BZ   A1ed8     ; 1ec1 84 16
                LIS  7         ; 1ec3 77
                XS   S         ; 1ec4 ec
                LR   S,A       ; 1ec5 5c
                OUTS 0         ; 1ec6 b0
                LIS  1         ; 1ec7 71
                SL   4         ; 1ec8 15
                OUTS 1         ; 1ec9 b1
                CLR            ; 1eca 70
                OUTS 1         ; 1ecb b1
                DCI  $08fb     ; 1ecc 2a 08 fb
                LISL 0         ; 1ecf 68
                LM             ; 1ed0 16
                AS   S         ; 1ed1 cc
                DCI  $08f0     ; 1ed2 2a 08 f0
                ST             ; 1ed5 17
                BR   A1ee6     ; 1ed6 90 0f
A1ed8:          LISL 0         ; 1ed8 68
                CLR            ; 1ed9 70
                LR   S,A       ; 1eda 5c
                LIS  8         ; 1edb 78
                LISU 2         ; 1edc 62
                LISL 0         ; 1edd 68
                XS   S         ; 1ede ec
                LR   S,A       ; 1edf 5c
                DCI  $08f7     ; 1ee0 2a 08 f7
                ST             ; 1ee3 17
                CLR            ; 1ee4 70
                OUTS 14        ; 1ee5 be
A1ee6:          LR   DC,H      ; 1ee6 10
                LISU 7         ; 1ee7 67
                LISL 3         ; 1ee8 6b
                LR   A,D       ; 1ee9 4e
                LR   $b,A      ; 1eea 5b
                LR   A,D       ; 1eeb 4e
                LR   $a,A      ; 1eec 5a
                LR   W,J       ; 1eed 1d
                LR   A,D       ; 1eee 4e
                LR   $9,A      ; 1eef 59
                LR   A,S       ; 1ef0 4c
                LR   IS,A       ; 1ef1 0b
                LR   A,$8      ; 1ef2 48
                EI             ; 1ef3 1b
                POP            ; 1ef4 1c
;        *
;        *
A1ef5:          LISU 6         ; 1ef5 66
                LISL 0         ; 1ef6 68
                CLR            ; 1ef7 70
                XS   I         ; 1ef8 ed
;PAGE 95 96
                BZ   A1f2a     ; 1ef9 84 30
                SL   1         ; 1efb 13
                SR   4         ; 1efc 14
                AI   $02       ; 1efd 24 02
                LR   S,A       ; 1eff 5c
                LI   $40       ; 1f00 20 40
A1f02:          SR   1         ; 1f02 12
                DS   S         ; 1f03 3c
                BNZ  A1f02     ; 1f04 94 fd
                LR   I,A       ; 1f06 5d
                LI   $1e       ; 1f07 20 1e
                OUTS 12        ; 1f09 bc
                LI   $b1       ; 1f0a 20 b1
                OUTS 13        ; 1f0c bd
                LIS  6         ; 1f0d 76
                LR   S,A       ; 1f0e 5c
                OUTS 0         ; 1f0f b0
                LIS  1         ; 1f10 71
                SL   4         ; 1f11 15
                OUTS 1         ; 1f12 b1
                CLR            ; 1f13 70
                OUTS 1         ; 1f14 b1
                LIS  1         ; 1f15 71
                OUTS 14        ; 1f16 be
                DCI  $08fb     ; 1f17 2a 08 fb
                LISL 0         ; 1f1a 68
                LM             ; 1f1b 16
                AS   S         ; 1f1c cc
                DCI  $08f0     ; 1f1d 2a 08 f0
                ST             ; 1f20 17
                LIS  8         ; 1f21 78
                LISU 2         ; 1f22 62
                XS   S         ; 1f23 ec
                LR   S,A       ; 1f24 5c
                DCI  $08f7     ; 1f25 2a 08 f7
                ST             ; 1f28 17
                EI             ; 1f29 1b
;        *
A1f2a:          POP            ; 1f2a 1c
;        *
;        *JOYSTICK INPUT ROUTINE*
;        ************************
A1f2b:          LR   K,P       ; 1f2b 08
                LISU 2         ; 1f2c 62
                LISL 0         ; 1f2d 68
                LR   A,$b      ; 1f2e 4b
                DCI  $08f0     ; 1f2f 2a 08 f0
                ST             ; 1f32 17
                LR   A,$a      ; 1f33 4a
                OUTS 0         ; 1f34 b0
;        *
                LI   $1f       ; 1f35 20 1f
                OUTS 12        ; 1f37 bc
                LI   $83       ; 1f38 20 83
                OUTS 13        ; 1f3a bd
;        *
                LIS  1         ; 1f3b 71
                OUTS 14        ; 1f3c be
;        *
                EI             ; 1f3d 1b
;        *
                LIS  8         ; 1f3e 78
                XS   S         ; 1f3f ec
                LR   S,A       ; 1f40 5c
                DCI  $08f7     ; 1f41 2a 08 f7
                ST             ; 1f44 17
;        *
;PAGE 97 98
A1f45:          BR   A1f45     ; 1f45 90 ff
;        *
;        *
;        *
;        *MAP X-Y FREEZE READINGS INTO SCREEN COORDINATES
A1f47:          DCI  $08f9     ; 1f47 2a 08 f9
                LR   A,$b      ; 1f4a 4b
                COM            ; 1f4b 18
                INC            ; 1f4c 1f
                AM             ; 1f4d 88
                LR   $a,A      ; 1f4e 5a
                CLR            ; 1f4f 70
                LR   $b,A      ; 1f50 5b
                LR   DC,H      ; 1f51 10
                LI   $e4       ; 1f52 20 e4
A1f54:          ADC            ; 1f54 8e
                DS   $a        ; 1f55 3a
                BNZ  A1f54     ; 1f56 94 fd
                XDC            ; 1f58 2c
                DCI  $08f8     ; 1f59 2a 08 f8
                CLR            ; 1f5c 70
                XM             ; 1f5d 8c
                XDC            ; 1f5e 2c
                ADC            ; 1f5f 8e
                LI   $eb       ; 1f60 20 eb
                ADC            ; 1f62 8e
                LR   H,DC      ; 1f63 11
                LI   $fe       ; 1f64 20 fe
                BP   A1f6a     ; 1f66 81 03
                AI   $01       ; 1f68 24 01
A1f6a:          AS   $a        ; 1f6a ca
                BP   A1f70     ; 1f6b 81 04
                CLR            ; 1f6d 70
                BR   A1f79     ; 1f6e 90 0a
A1f70:          BNZ  A1f77     ; 1f70 94 06
                LR   A,$b      ; 1f72 4b
                CI   $c7       ; 1f73 25 c7
                BC   A1f79     ; 1f75 82 03
A1f77:          LI   $c7       ; 1f77 20 c7
A1f79:          LR   $a,A      ; 1f79 5a
;        *
                LIS  2         ; 1f7a 72
                XS   S         ; 1f7b ec
                LR   S,A       ; 1f7c 5c
                DCI  $08f7     ; 1f7d 2a 08 f7
                ST             ; 1f80 17
;        *
                LR   A,$a      ; 1f81 4a
                PK             ; 1f82 0c
;        *
                LI   $80       ; 1f83 20 80
                OUTS 1         ; 1f85 b1
;        *
                LI   $1f       ; 1f86 20 1f
                OUTS 12        ; 1f88 bc
                LI   $96       ; 1f89 20 96
                OUTS 13        ; 1f8b bd
;        *
                LIS  $a        ; 1f8c 7a
                XS   S         ; 1f8d ec
                LR   S,A       ; 1f8e 5c
                DCI  $08f7     ; 1f8f 2a 08 f7 -- guess
                ST             ; 1f92 17
;        *
                EI             ; 1f93 1b
A1f94:          BR   A1f94     ; 1f94 90 ff
;PAGE 99 100
                CLR            ; 1f96 70
                OUTS 1         ; 1f97 b1
                OUTS 14        ; 1f98 be
                BR   A1f47     ; 1f99 90 ad

         org $1fff             ;pad to 4K
         db  $ff

